## HTML, CSS and Javascript for Web Developers (by Johns Hopkins University)
Course Link:  https://www.coursera.org/learn/html-css-javascript-for-web-developers 

Week #2 Coding Assignment Solution
------------------------------------------------------------
Description   : https://github.com/jhu-ep-coursera/fullstack-course4/blob/master/assignments/assignment2/Assignment-2.md 
Solution Link : https://3024k.github.io/HTML-CSS-Javascript-for-Web-Developers/module2-solution/    

Week #3 Coding Assignment Solution
------------------------------------------------------------
Description   : https://github.com/jhu-ep-coursera/fullstack-course4/blob/master/assignments/assignment3/Assignment-3.md
Solution Link : https://3024k.github.io/HTML-CSS-Javascript-for-Web-Developers/module3-solution/  

Week #4 Coding Assignment Solution
------------------------------------------------------------
Description   : https://github.com/jhu-ep-coursera/fullstack-course4/blob/master/assignments/assignment4/Assignment-4.md
Solution Link : https://3024k.github.io/HTML-CSS-Javascript-for-Web-Developers/module4-solution/

Week #5 Coding Assignment Solution
------------------------------------------------------------
Description   : https://github.com/jhu-ep-coursera/fullstack-course4/blob/master/assignments/assignment5/Assignment-5.md
Solution Link : https://3024k.github.io/HTML-CSS-Javascript-for-Web-Developers/module5-solution/


